# 课派助手 V0.2 — 手机端编译测试项目

这是一个可供 AndroidIDE 导入的 Android Java/Gradle 源码项目，不是 APK。尚未在真实安卓设备上完成编译验证。

## 功能
- 无障碍服务启用检测
- 读取当前窗口的可访问文字节点
- 自带两道模拟题及自动点击指定选项的测试按钮
- 无网络请求、无 AI、无 OCR、无微信控制、无自动提交

## 手机安装流程
1. 在 AndroidIDE 官方项目页面核实最新安装和初始化说明：https://github.com/AndroidIDEOfficial/AndroidIDE
2. 安装 AndroidIDE 并按其引导安装 JDK、SDK、Gradle 所需工具。手机需要足够空间和网络。
3. 解压此 ZIP，在 AndroidIDE 中打开 `KepaiAssistPhone` 文件夹（包含 settings.gradle）。
4. 运行 Gradle 同步，选择 Build APK。不同 AndroidIDE 版本的菜单名称可能不同。
5. 构建成功后安装生成的 debug APK，允许“安装未知应用”（如系统要求）。
6. 打开应用，点击“打开无障碍设置”，启用“课派助手测试版”服务。
7. 回到应用，检查服务，再打开模拟题，点击“测试自动点击正确选项”。

## 已知限制
- 无法保证 AndroidIDE 与 Gradle 8.2.2、compileSdk 34 在每台手机兼容；如有报错请保留构建日志。
- 不能读取仅在画布/WebView 中渲染、未暴露无障碍节点的文字；后续需要 MediaProjection + OCR。
- `targetSdk 28` 仅为降低测试应用的兼容复杂度，不建议用于正式发布；新系统可能提示旧版应用风险或限制无障碍授权。
- 任何正式考试自动化都应经过主办方许可和模拟环境验证。
