package com.example.kepaiassist;
import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;

public class AssistService extends AccessibilityService {
  static AssistService current;
  @Override protected void onServiceConnected() { current=this; }
  @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
  @Override public void onInterrupt() { }
  @Override public void onDestroy() { if(current==this)current=null; super.onDestroy(); }
  String readCurrent() {
    AccessibilityNodeInfo root=getRootInActiveWindow();
    if(root==null)return "未取得窗口节点，请检查授权";
    List<String> lines=new ArrayList<>(); traverse(root,lines);
    return lines.isEmpty()?"没有可访问文字；此页面可能需要 OCR":android.text.TextUtils.join("\n",lines);
  }
  private void traverse(AccessibilityNodeInfo node,List<String> lines) {
    if(node==null)return;
    if(node.getText()!=null && node.getText().length()>0) lines.add(node.getText().toString());
    for(int i=0;i<node.getChildCount();i++)traverse(node.getChild(i),lines);
  }
  boolean clickExact(String target) {
    AccessibilityNodeInfo root=getRootInActiveWindow();
    if(root==null)return false;
    List<AccessibilityNodeInfo> matches=root.findAccessibilityNodeInfosByText(target);
    for(AccessibilityNodeInfo m:matches){
      if(m.getText()==null || !target.equals(m.getText().toString().trim()))continue;
      AccessibilityNodeInfo n=m;
      while(n!=null){if(n.isClickable() && n.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;n=n.getParent();}
    }
    return false;
  }
}
