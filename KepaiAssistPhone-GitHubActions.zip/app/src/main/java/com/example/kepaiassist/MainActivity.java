package com.example.kepaiassist;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
 TextView output; LinearLayout root; int index=0; String[] questions={"模拟题 1：2 + 2 等于多少？","模拟题 2：仪表信号常见单位是？"};
 @Override public void onCreate(Bundle b){super.onCreate(b); showHome();}
 TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(16,18,16,18);return t;}
 Button button(String label,View.OnClickListener cb){Button b=new Button(this);b.setText(label);b.setOnClickListener(cb);return b;}
 void base(String title){ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setPadding(22,28,22,22);root.setOrientation(1);sc.addView(root);setContentView(sc);root.addView(text(title,23));}
 void showHome(){base("课派助手 V0.2 · 测试版");root.addView(text("本版本只验证系统无障碍服务和自带模拟题。不会自动进入微信、答题或提交试卷。",15));root.addView(button("1. 打开无障碍设置",v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));root.addView(button("2. 检查服务并读取当前页面",v->{AssistService a=AssistService.current;output.setText(a==null?"服务未启用，请在设置中授权":"服务已连接。\n"+a.readCurrent());}));root.addView(button("3. 打开模拟题",v->showQuiz()));output=text("等待检查",15);root.addView(output);}
 void showQuiz(){base(questions[index]);root.addView(text("选择答案后显示结果。这里的按钮供无障碍点击测试。",15));String[] options=index==0?new String[]{"A. 3","B. 4","C. 5"}:new String[]{"A. mA","B. kg","C. km"};for(String opt:options)root.addView(button(opt,v->output.setText("已点击："+opt)));output=text("尚未选择",17);root.addView(output);root.addView(button("测试自动点击正确选项",v->{AssistService a=AssistService.current;String expected=index==0?"B. 4":"A. mA";output.setText(a==null?"请先启用无障碍服务":a.clickExact(expected)?"点击命令已发送："+expected:"未找到可点击选项");}));root.addView(button("下一题（手动）",v->{index=(index+1)%questions.length;showQuiz();}));root.addView(button("返回首页",v->showHome()));}
}
